import React from 'react';
import './style.css';



export default class ButtonSec extends React.Component {


	
	render(){ 
	
		return(
			<div className="">

			      	<div className="inline-block text-center">
			      		<a href="#" className="btn btn-primary1" >Log in</a>
			      		<a href="#" className="btn btn-success" >Sign Up</a>
			      	</div>
			</div>
			);
		}
	}