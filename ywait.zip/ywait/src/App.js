import React, { Component } from 'react';
import'./App.css';
// import FirstScreen from './Components/FirstScreen/index.js';
// import SecondScreen from './Components/SecondScreen/index.js';
import ThirdScreen from './Components/ThirdScreen/index.js';


class App extends Component {
  render() {
    return (
      <div>
       <ThirdScreen/>
      </div>
    );
  }
}

export default App;
